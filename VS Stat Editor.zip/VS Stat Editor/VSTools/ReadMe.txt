
 FILENAME : VSTOOLS
 FILEDATE : 23/02/2012
 AUTHOR   : Valendian
 PURPOSE  : To moddify Vagrant Story data files.

 This is a small toolchain to get the ball rolling. The full toolchain
 is still in development. These tools are being made available to give
 people a chance to get started modding Vagrant Story and can't wait.

 To make use of these tools you will need FASM which can be downloaded
 for free from this url:
     http://flatassembler.net/

 Kildean.exe
     A gui text conversion utility, useful for converting text to/from
     ansi and Vagrant Story's internal character set.

 TextTool.exe
     A console text conversion utility. Haven't tracked down all of the
     bugs in Kildean.exe. This tool is less error prone.

 znddasm.exe
     A ZND file disassembler. This tool takes ZND files as input and it
     produces ASM files as output. The ASM files can then be editted at
     will and later reassembled back into ZND files using FASM. This is
     the tool you need to use to modify enemy stats and equipment, etc.

 mpdtool.exe
     An MPD file disassembler. This tool takes MPD files as input and
     it produces ASM files as output. The ASM files can then be editted
     at will and later reassembled back into MPD files using FASM. This
     is the tool you need to use to modify treasure chest contents, the
     games cut scenes, the appearance of the room (though this is not
     encouraged due to the fact that this tool chain is text driven).
